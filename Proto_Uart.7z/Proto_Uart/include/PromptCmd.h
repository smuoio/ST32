/**
 * \file PromptCmd
 * \brief the file manages the prompt functions, functions used from the end user
 */

#ifndef __PROMPTCMD_H__
#define __PROMPTCMD_H__

#include "Typedef.h"
/**
 * \struct t_TabFun
 * \brief structure manages all function configured
 */
typedef struct
{
	uint8_t cmd; /*!< command  */
	void (*pfun)(void); /*!< pointer function addressed to the function developed  */
}t_TabFun;
/**
 * \fn void help(void)
 * \brief the help function, shows all function developed in the board
 *
 */
void help(void);
/**
 * \fn void status(void)
 * \brief the functions manages the staus of board
 */
void status(void);

static void rdummy(void){};
/**
 * \fn void PromptCmd(void)
 * \brief function manages the prompt
 */

void PromptCmd(void);
/**
 * \fn e_result getcmd(uint8_t *pCmd)
 * \brief the function get the cmd from the shell
 * \param *pCmd, command
 * \return the status of check pointer
 */
e_result getcmd(uint8_t *cmd);
/**
 * \fn e_result checkfun(uint8_t *cmd)
 * \brief function used to check which command is written in the consolle IO
 * @param cmd
 * @return the status of check
 */
e_result checkfun(uint8_t *cmd);

#endif
