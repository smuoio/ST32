/**
 * \file IOMap.h
 * \brief the file manages the memory IO
 *  Created on: 24 set 2020
 *      Author: CAF_117
 */

#ifndef INCLUDE_TESTIOMAP_H_
#define INCLUDE_TESTIOMAP_H_
#include "stm32f4xx_hal.h"
#include "Typedef.h"

// define the local variable used to set the IO


/**
 * \fn void TestIOMap_init(void)
 * \brief the function have to initialize the IO used in board to implement the tests
 */
//extern GPIO_InitTypeDef GPIO_TstInitStructure;

/**
 * \fn void TestIOMap_init(void)
 * \brief the function is used to initialize the pin used for the tests
 */
void TestIOMap_init(void);
/**
 * \fn e_result SetIO(GPIO_TypeDef  *GPIOx, uint16_t pin2set, uint8_t value)
 * \brief the function is used to set/rest the pin
 * \param GPIOx is the address area A,B,C,D,E, F
 * \param pint2set is the specific pin (i.e GPIO_PIN_12)
 * \param value is the value TRUE or FALSE for the pin (i.e GPIO_PIN_RESET = 0,
          GPIO_PIN_SET)
 *\return ok if the pointer is addressed
 */
e_result SetIO(GPIO_TypeDef  *GPIOx, uint16_t pin2set, uint8_t value);
/**
 * \fn e_result ReadIO(GPIO_TypeDef  *GPIOx, uint16_t pin2set, GPIO_PinState *pvalue)
 * \brief the function is used to read the pin
 * \param GPIOx is the address area A,B,C,D,E, F
 * \param pint2set is the specific pin (i.e GPIO_PIN_12)
 * \param value is the value TRUE or FALSE for the pin (i.e GPIO_PIN_RESET = 0,
          GPIO_PIN_SET)
 *\return ok if the pointer is addressed
 */
e_result ReadIO(GPIO_TypeDef  *GPIOx, uint16_t pin2set, GPIO_PinState *pvalue);

#endif /* INCLUDE_IOMAP_H_ */
