/**
 * \file TestManager.h
 * \brief header file
 *  Created on: 14 set 2020
 *      Author:  Salvatore Muoio
 */

#ifndef INCLUDE_TESTMANAGER_H_
#define INCLUDE_TESTMANAGER_H_

/**
 * \fn void TestManager(void)
 * \brief the function calls the test schedule
 */
void TestManager(void);


#endif /* INCLUDE_TESTMANAGER_H_ */
