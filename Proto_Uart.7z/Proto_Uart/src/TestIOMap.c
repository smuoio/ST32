/**
 * \file TestIOMap.c
 *
 *  Created on: 01 ott 2020
 *      Author: Salvatore Muoio
 */
#include "Util.h"
#include "TestIOMap.h"


void TestIOMap_init(void)
{

	GPIO_InitTypeDef GPIO_TstInitStructure;

	// Configure pin in output push/pull mode
	GPIO_TstInitStructure.Pin = GPIO_PIN_12;
	GPIO_TstInitStructure.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_TstInitStructure.Speed = GPIO_SPEED_FAST;
	GPIO_TstInitStructure.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOA, &GPIO_TstInitStructure);
}


e_result SetIO(GPIO_TypeDef  *GPIOx, uint16_t pin2set, uint8_t value)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((GPIO_TypeDef*)GPIOx);
	if(RESULT_SUCCEEDED(lRet))
		HAL_GPIO_WritePin(GPIOx, pin2set, value);
	return(lRet);
}

e_result ReadIO(GPIO_TypeDef  *GPIOx, uint16_t pin2set, GPIO_PinState *pvalue)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((GPIO_PinState*)pvalue);
	lRet |= CheckArg((GPIO_TypeDef*)GPIOx);
	if(RESULT_SUCCEEDED(lRet))
		*pvalue = HAL_GPIO_ReadPin(GPIOx, pin2set);
	return(lRet);
}
