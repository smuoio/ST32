/**
 * \file TestManager_impl.c
 * \brief the manages the private function test
 *  Created on: 14 set 2020
 *      Author: Salvatore Muoio
 */
#include <stdio.h>
#include <string.h>
#include "stm32f4xx_hal.h"
#include "Retarget.h"
#include "Timer.h"
#include "TestManager_impl.h"
#include "TestIOMap.h"


/**
 * TODO: implement the time sequence correct!!!
 */

#define TIME 1000
void TestCheck(void)
{
	static uint16_t timeout = 0x0U;
	//set Test
	//if(timeout == 0x0U)
	timer_sleep(timeout == 0 ? 1000: 1);
	if (SetIO(GPIOA, GPIO_PIN_12, GPIO_PIN_SET) == RESULT_POINTER_NOT_ADDRESSED)
	{
		// set diag!!!
		char *msg = " !!!! error in SET IO address memory!!!! \n\r";
		int len = strlen(msg);
		Stm32WriteString((uint8_t*)msg, len);
	}

	++timeout;
	//if((++timeout)>= TIME)
	timer_sleep(1);
	SetIO(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET); //== RESULT_POINTER_NOT_ADDRESSED)
	// check read input!!!
	printf("timeout  = %x\n\r", timeout);
	//timeout = 0x0U;
}

void TestCheckInput(void)
{

}


void TestDummy(void)
{;}
