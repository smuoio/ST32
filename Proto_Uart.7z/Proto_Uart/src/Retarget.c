/**
 * \file Retarget.h
 * \brief the file manages all functions used for the consolle IO
 * using the STM32 Nucleo we are using the USART 2
 */

#include "Retarget.h"
#include <string.h>

/**
 * \var huart2
 * variable huart assigned to the structure UART_HandleTypeDef
 */
extern UART_HandleTypeDef huart2;


e_result Stm32WriteChar(uint8_t *pChar)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((uint8_t*)pChar);
	if(RESULT_SUCCEEDED(lRet))
	{
		//write single char
		//uint8_t c = (*pChar&(0x00FF));
		HAL_UART_Transmit(&huart2, (uint8_t*)pChar, 1, 0xFFFF);
	}
	return(lRet);
}

e_result Stm32WriteString(uint8_t *pChar, uint32_t Size)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((uint8_t*)pChar);
	if(RESULT_SUCCEEDED(lRet))
	{
		//write single char
		//uint8_t c = (*pChar&(0x00FF));
		HAL_UART_Transmit(&huart2, (uint8_t*)pChar, Size, 0xFFFF);
		Stm32flush();
	}
	return(lRet);
}

void Stm32flush(void)
{
	//__HAL_UART_FLUSH_DRREGISTER(((UART_HandleTypeDef *) huart2));
	//huart2.Instance->DR;
	memset(huart2.pTxBuffPtr,0,huart2.TxXferSize);
}



e_result Stm32ReadChar(uint8_t *pChar)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((uint8_t*)pChar);

	if(RESULT_SUCCEEDED(lRet))
	{
		//read a single chat
		uint8_t c;
		HAL_UART_Receive(&huart2, (uint8_t*)&c, 1, 0xFFFF);
		*pChar = c;
	}
	return(lRet);
}

