/**
 * \file Util.c
 * \brief the file manages all utility functions
 */

#include "Util.h"

e_result CheckArg(void *pArg)
{
	return((pArg != 0) ? RESULT_OK : RESULT_POINTER_NOT_ADDRESSED);
}

e_result RisingEdge(e_bool inp, e_bool * const out)
{
	e_result lRet = RESULT_OK;
	static e_bool tmp = FALSE;
	lRet |= CheckArg((e_bool*)out);
	if(RESULT_SUCCEEDED(lRet))
	{
		*out = inp&!tmp;
		tmp  = inp;
	}
	return(lRet);
}

e_result FallingEdge(e_bool inp, e_bool * const out)
{
	e_result lRet = RESULT_OK;
	static e_bool tmp = FALSE;
	lRet |= CheckArg((e_bool*)out);
	if(RESULT_SUCCEEDED(lRet))
	{
		*out = !inp&tmp;
		tmp  = inp;
	}
	return(lRet);
}

e_result ConvUint32toBool(const unsigned int inp, e_bool* const pout)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((e_bool*)pout);
	if(RESULT_SUCCEEDED(lRet))
	{
		*pout = FALSE;
		if (inp == 0x1U) *pout = TRUE ;
	}
	return(lRet);
}
