/**
 * \file PromptCmd_impl.c
 * \brief the file manages all methods described in the consolle
 */
#include <string.h>
#include "Retarget.h"
#include "PromptCmd.h"


void help(void)
{
	char *msg = "\t *******help function******* \n\r";
	int len = strlen(msg);
	//HAL_UART_Receive(&huart2, (char*)msg, 8, 0xFFFF);
	Stm32WriteString((uint8_t*)msg, len);
	msg = "s  status board ";
	len = strlen(msg);
	Stm32WriteString((uint8_t*)msg, len);
	msg = "\t st  single test to run \n\r";
	len = strlen(msg);
	Stm32WriteString((uint8_t*)msg, len);


}

void status(void)
{
	char *msg = "**** status function**** \n\r";
	int len = strlen(msg);
	Stm32WriteString((uint8_t*)msg, len);
	msg = "Board STM32F446 Nucleo-64 \n\r";
	len = strlen(msg);
	Stm32WriteString((uint8_t*)msg, len);
}
