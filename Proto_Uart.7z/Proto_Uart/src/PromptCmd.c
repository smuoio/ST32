/**
 * \file PromptCmd.c
 * \brief the file manages the prompt functions
 */
//#include "stm32f4xx_hal.h"
#include <string.h>
#include "Retarget.h"
#include "PromptCmd.h"
/**
 * \def MAXINDEXFUN
 * \brief max index function consoole
 */
#define MAXINDEXFUN 3
const t_TabFun TabFun[MAXINDEXFUN] = {{'h',help},{'s',status}, {'d',rdummy}};
/**
 * \var huart2
 * \brief variable huart assigned to the structure UART_HandleTypeDef
 */
//extern UART_HandleTypeDef huart2;

void PromptCmd(void)
{
	uint8_t cmd = 0x0U;//command
	static uint8_t charfun = 0x0U;
	getcmd(&cmd);
	if(cmd == '\n')
	{
	/*check function*/
		checkfun(&charfun);
		charfun = 0x0U;
	}
	else
		charfun = cmd;


}


e_result getcmd(uint8_t *cmd)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((uint8_t*)cmd);
	if(RESULT_SUCCEEDED(lRet))
	{
		{
			Stm32ReadChar(cmd);
			if(*cmd == '\r'){
				Stm32WriteChar(cmd);/**echo*/
				*cmd = '\n';
			}
			Stm32WriteChar(cmd);
		}
	}
	return(lRet);
}

e_result checkfun(uint8_t *cmd)
{
	e_result lRet = RESULT_OK;
	lRet |= CheckArg((uint8_t*)cmd);
	if(RESULT_SUCCEEDED(lRet))
	{
		int ii = 0x0;// for index
		// for used to check if command exist and callback the right function
		for(;ii<2;ii++)
		{
			if(*cmd == TabFun[ii].cmd)
			{
				TabFun[ii].pfun();
				break;
			}
		}
	}
	return(lRet);
}



