/**
 * \file Pwm.h
 *\brief header file
 *  Created on: 10 giu 2021
 *      Author: SMUOIO
 */

#ifndef INCLUDE_PWM_H_
#define INCLUDE_PWM_H_

typedef struct
{
	uint16_t frequency;
	uint16_t duty_cycle;
}t_pwm;

t_pwm *GetPwm(void);

#endif /* INCLUDE_PWM_H_ */
