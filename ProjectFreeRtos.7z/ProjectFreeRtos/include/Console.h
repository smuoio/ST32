/*
 *\file  Consolle.h
 *
 *  Created on: 14 mar 2021
 *      Author: Salvatore Muoio
 */

#ifndef INCLUDE_CONSOLLE_H_
#define INCLUDE_CONSOLLE_H_


void Console(void);


#endif /* INCLUDE_CONSOLLE_H_ */
