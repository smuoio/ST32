/**
 * \file Config.c
 * \brief the file manages the configuration board
 *  Created on: 29 mar 2021
 *  Author: Salvatore Muoio
 */

#include "Config.h"

/**
* \var t_config config
* \brief static variable to the object the configuration struct
*/
static t_config config;

void ConfigInit(void)
{

}

t_config *GetConfig(void)
{
	return(&config);
}
