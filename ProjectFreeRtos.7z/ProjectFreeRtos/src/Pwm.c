/**
 * \file Pwm.c
 * \brief source file manages the pwm functions and set up
 *
 *  Created on: 10 giu 2021
 *      Author: SMUOIO
 */
#include "Pwm.h"

static t_pwm pwm;


t_pwm *GetPwm(void)
{
	return(&pwm);
}
